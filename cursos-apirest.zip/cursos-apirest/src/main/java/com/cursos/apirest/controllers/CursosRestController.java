package com.cursos.apirest.controllers;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cursos.apirest.models.entities.Curso; 
import com.cursos.apirest.models.services.IGeneralService;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/api")
public class CursosRestController {
	@Autowired
	private IGeneralService<Curso> cursoService;
	
	@GetMapping("/cursos")
	public ResponseEntity<?> findAll(){
		
		Map<String, Object> response = new LinkedHashMap<>();
		List<Curso> resultado = new ArrayList<>();
		
		try {
			
			resultado =  cursoService.findAll();
			
		}catch(DataAccessException e) {
			
			response.put("mensaje", "Error al realizar la búsqueda de todos los Cursos en la BBDD");
			response.put("fecha",LocalDateTime.now());
			response.put("error", e.getMessage().concat(":").concat(e.getMostSpecificCause().getMessage()));
			return new ResponseEntity< Map<String, Object> >(response,HttpStatus.INTERNAL_SERVER_ERROR );
			
		}
		
		response.put("mensaje", "El listado de todos los Cursos se ha efectuado con éxito.");
		response.put("fecha",LocalDateTime.now());
		response.put("datos", resultado);
		return new ResponseEntity<  Map<String,  Object > >(response,HttpStatus.OK); 
		
	}
	
	@GetMapping("/curso/{id}")
	public ResponseEntity<?> findById(@PathVariable Long id) {
		
		
		Map<String, Object> response = new LinkedHashMap<>();
		Curso resultado = null;
		
		try {
			
			resultado =  cursoService.findById(id);
			
		}catch(DataAccessException e) {
			
			response.put("mensaje", "Error al realizar la búsqueda del Curso con id: " + id + " en la BBDD");
			response.put("fecha",LocalDateTime.now());
			response.put("error", e.getMessage().concat(":").concat(e.getMostSpecificCause().getMessage()));
			return new ResponseEntity< Map<String, Object> >(response,HttpStatus.INTERNAL_SERVER_ERROR );
			
		}
		
		response.put("mensaje", "La búsqueda del Curso con id: " + id + " se ha efectuado con éxito");
		response.put("fecha",LocalDateTime.now());
		response.put("datos", resultado);
		return new ResponseEntity<  Map<String,  Object > >(response,HttpStatus.OK);
				
		
		
	}
	
	@PostMapping("/curso")
	public ResponseEntity<?> create(@RequestBody Curso curso) {
		
		
		Map<String, Object> response = new LinkedHashMap<>();
		Curso resultado = null;
		
		try {
			
			resultado =  cursoService.save(curso);
		
		}catch(DataIntegrityViolationException e) {
				
			response.put("mensaje", "Error al intentar crear el Curso en la BBDD porque probablemente ya exista");
			response.put("fecha",LocalDateTime.now());
			response.put("error", e.getMessage().concat(":").concat(e.getMostSpecificCause().getMessage()));
			return new ResponseEntity< Map<String, Object> >(response,HttpStatus.BAD_REQUEST );
			
		}catch(DataAccessException e) {
			
			response.put("mensaje", "Error al intentar crear el Curso en la BBDD");
			response.put("fecha",LocalDateTime.now());
			response.put("error", e.getMessage().concat(":").concat(e.getMostSpecificCause().getMessage()));
			return new ResponseEntity< Map<String, Object> >(response,HttpStatus.INTERNAL_SERVER_ERROR );
			
		}
		
		response.put("mensaje", "El Curso se ha creado con éxito");
		response.put("fecha",LocalDateTime.now());
		response.put("datos", resultado);
		return new ResponseEntity<  Map<String,  Object > >(response,HttpStatus.OK);

		
		
		
		
	}
	
	@PutMapping("/curso")
	public ResponseEntity<?> update(@RequestBody Curso curso) {
		
		Map<String, Object> response = new LinkedHashMap<>();
		Curso resultado = null;
		
		try {
			
			resultado =  cursoService.save(curso);
		
		}catch(DataIntegrityViolationException e) {
				
			response.put("mensaje", "Error al intentar modificar el Curso en la BBDD porque el campo modificado probablemente ya exista");
			response.put("fecha",LocalDateTime.now());
			response.put("error", e.getMessage().concat(":").concat(e.getMostSpecificCause().getMessage()));
			return new ResponseEntity< Map<String, Object> >(response,HttpStatus.BAD_REQUEST );

			
		}catch(DataAccessException e) {
			
			response.put("mensaje", "Error al intentar modificar el Curso en la BBDD");
			response.put("fecha",LocalDateTime.now());
			response.put("error", e.getMessage().concat(":").concat(e.getMostSpecificCause().getMessage()));
			return new ResponseEntity< Map<String, Object> >(response,HttpStatus.INTERNAL_SERVER_ERROR );

			
		}
		
		response.put("mensaje", "El Curso se ha modificado con éxito");
		response.put("fecha",LocalDateTime.now());
		response.put("datos", resultado);
		return new ResponseEntity<  Map<String,  Object > >(response,HttpStatus.OK);

		
		
	}
	@DeleteMapping("/curso/{id}")
	public ResponseEntity<?> deleteById(@PathVariable Long id) {
		
		
		Map<String, Object> response = new LinkedHashMap<>();

	    try {
	        Curso curso = cursoService.findById(id);
	        if (curso == null) {
	            response.put("mensaje", "No se encontró el estudiante con ID: " + id);
	            response.put("fecha", LocalDateTime.now());
	            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
	        }

	        cursoService.deleteById(id);
	        response.put("mensaje", "Estudiante eliminado con éxito");
	        response.put("fecha", LocalDateTime.now());
	        return new ResponseEntity<>(response, HttpStatus.OK);

	    } catch (DataAccessException e) {
	        response.put("mensaje", "Error al intentar eliminar el estudiante");
	        response.put("fecha", LocalDateTime.now());
	        response.put("error", e.getMessage().concat(": ").concat(e.getMostSpecificCause().getMessage()));
	        return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
		
		
			
		
	}
}
