package com.cursos.apirest.controllers;

import java.time.LocalDateTime;
import java.util.ArrayList;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;

import com.cursos.apirest.models.entities.Curso;
import com.cursos.apirest.models.entities.Estudiante;
import com.cursos.apirest.models.services.IGeneralService;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/api")
public class EstudianteRestController {

	@Autowired
	private IGeneralService<Estudiante> estudianteService;
	@Autowired
	private IGeneralService<Curso> cursoService;
	
	@GetMapping("/estudiantes")
	public ResponseEntity<?> findAll(){
		
		Map<String, Object> response = new LinkedHashMap<>();
		List<Estudiante> resultado = new ArrayList<>();
		
		try {
			
			resultado =  estudianteService.findAll();
			
		}catch(DataAccessException e) {
			
			response.put("mensaje", "Error al realizar la búsqueda de todos los estudiantes en la BBDD");
			response.put("fecha",LocalDateTime.now());
			response.put("error", e.getMessage().concat(":").concat(e.getMostSpecificCause().getMessage()));
			return new ResponseEntity< Map<String, Object> >(response,HttpStatus.INTERNAL_SERVER_ERROR );
			
		}
		
		response.put("mensaje", "El listado de todos los estudiantes se ha efectuado con éxito.");
		response.put("fecha",LocalDateTime.now());
		response.put("datos", resultado);
		return new ResponseEntity<  Map<String,  Object > >(response,HttpStatus.OK); 
		
	}
	
	@GetMapping("/estudiante/{id}")
	public ResponseEntity<?> findById(@PathVariable Long id) {
		
		
		Map<String, Object> response = new LinkedHashMap<>();
		Estudiante resultado = null;
		
		try {
			
			resultado =  estudianteService.findById(id);
			
		}catch(DataAccessException e) {
			
			response.put("mensaje", "Error al realizar la búsqueda del Estudiante con id: " + id + " en la BBDD");
			response.put("fecha",LocalDateTime.now());
			response.put("error", e.getMessage().concat(":").concat(e.getMostSpecificCause().getMessage()));
			return new ResponseEntity< Map<String, Object> >(response,HttpStatus.INTERNAL_SERVER_ERROR );
			
		}
		
		response.put("mensaje", "La búsqueda del Estudiante con id: " + id + " se ha efectuado con éxito");
		response.put("fecha",LocalDateTime.now());
		response.put("datos", resultado);
		return new ResponseEntity<  Map<String,  Object > >(response,HttpStatus.OK);
				
		
		
	}
	
	@PostMapping("/estudiante")
	public ResponseEntity<?> create(@RequestBody Estudiante estudiante) {
		
		
		Map<String, Object> response = new LinkedHashMap<>();
		Estudiante resultado = null;
		
		try {
			
			resultado =  estudianteService.save(estudiante);
		
		}catch(DataIntegrityViolationException e) {
				
			response.put("mensaje", "Error al intentar crear el Estudiante en la BBDD porque probablemente ya exista");
			response.put("fecha",LocalDateTime.now());
			response.put("error", e.getMessage().concat(":").concat(e.getMostSpecificCause().getMessage()));
			return new ResponseEntity< Map<String, Object> >(response,HttpStatus.BAD_REQUEST );
			
		}catch(DataAccessException e) {
			
			response.put("mensaje", "Error al intentar crear el Estudiante en la BBDD");
			response.put("fecha",LocalDateTime.now());
			response.put("error", e.getMessage().concat(":").concat(e.getMostSpecificCause().getMessage()));
			return new ResponseEntity< Map<String, Object> >(response,HttpStatus.INTERNAL_SERVER_ERROR );
			
		}
		
		response.put("mensaje", "El Estudiante se ha creado con éxito");
		response.put("fecha",LocalDateTime.now());
		response.put("datos", resultado);
		return new ResponseEntity<  Map<String,  Object > >(response,HttpStatus.OK);

		
		
		
		
	}
	
	@PutMapping("/estudiante")
	public ResponseEntity<?> update(@RequestBody Estudiante estudiante) {
		
		Map<String, Object> response = new LinkedHashMap<>();
		Estudiante resultado = null;
		
		try {
			
			resultado =  estudianteService.save(estudiante);
		
		}catch(DataIntegrityViolationException e) {
				
			response.put("mensaje", "Error al intentar modificar el Estudiante en la BBDD porque el campo modificado probablemente ya exista");
			response.put("fecha",LocalDateTime.now());
			response.put("error", e.getMessage().concat(":").concat(e.getMostSpecificCause().getMessage()));
			return new ResponseEntity< Map<String, Object> >(response,HttpStatus.BAD_REQUEST );

			
		}catch(DataAccessException e) {
			
			response.put("mensaje", "Error al intentar modificar el Estudiante en la BBDD");
			response.put("fecha",LocalDateTime.now());
			response.put("error", e.getMessage().concat(":").concat(e.getMostSpecificCause().getMessage()));
			return new ResponseEntity< Map<String, Object> >(response,HttpStatus.INTERNAL_SERVER_ERROR );

			
		}
		
		response.put("mensaje", "El Estudiante se ha modificado con éxito");
		response.put("fecha",LocalDateTime.now());
		response.put("datos", resultado);
		return new ResponseEntity<  Map<String,  Object > >(response,HttpStatus.OK);

		
		
	}
	
	@DeleteMapping("/estudiante/{id}")
	public ResponseEntity<?> deleteById(@PathVariable Long id) {
		
		
		Map<String, Object> response = new LinkedHashMap<>();

	    try {
	        Estudiante estudiante = estudianteService.findById(id);
	        if (estudiante == null) {
	            response.put("mensaje", "No se encontró el estudiante con ID: " + id);
	            response.put("fecha", LocalDateTime.now());
	            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
	        }

	        estudianteService.deleteById(id);
	        response.put("mensaje", "Estudiante eliminado con éxito");
	        response.put("fecha", LocalDateTime.now());
	        return new ResponseEntity<>(response, HttpStatus.OK);

	    } catch (DataAccessException e) {
	        response.put("mensaje", "Error al intentar eliminar el estudiante");
	        response.put("fecha", LocalDateTime.now());
	        response.put("error", e.getMessage().concat(": ").concat(e.getMostSpecificCause().getMessage()));
	        return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
		
		
			
		
	}
	
	
	
	@PostMapping("/estudiante/estudiante-{idEstudiante}/curso/curso-{idCurso}")
	public ResponseEntity<?> asignarCursoAEstudiante(@PathVariable Long idEstudiante, @PathVariable Long idCurso) {
	    Map<String, Object> response = new LinkedHashMap<>();

	    try {
	        Estudiante estudiante = estudianteService.findById(idEstudiante);
	        Curso curso = cursoService.findById(idCurso);

	        if (estudiante == null || curso == null) {
	            response.put("mensaje", "Estudiante o curso no encontrado");
	            response.put("fecha", LocalDateTime.now());
	            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
	        }

	        if (!estudiante.getCursos().contains(curso)) {
	            estudiante.getCursos().add(curso);
	            estudianteService.save(estudiante);
	        }

	        response.put("mensaje", "Curso asignado correctamente al estudiante");
	        response.put("fecha", LocalDateTime.now());
	        response.put("datos", estudiante.getCursos());
	        return new ResponseEntity<>(response, HttpStatus.OK);

	    } catch (Exception e) {
	        response.put("mensaje", "Error al asignar el curso al estudiante");
	        response.put("fecha", LocalDateTime.now());
	        response.put("error", e.getMessage());
	        return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	}
	
	@DeleteMapping("/estudiante/estudiante-{idEstudiante}/curso/curso-{idCurso}")
	public ResponseEntity<?> eliminarCursoDeEstudiante(@PathVariable Long idEstudiante, @PathVariable Long idCurso) {
	    Map<String, Object> response = new LinkedHashMap<>();

	    try {
	        Estudiante estudiante = estudianteService.findById(idEstudiante);
	        Curso curso = cursoService.findById(idCurso);

	        if (estudiante == null || curso == null) {
	            response.put("mensaje", "Estudiante o curso no encontrado");
	            response.put("fecha", LocalDateTime.now());
	            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
	        }

	        if (estudiante.getCursos().contains(curso)) {
	            estudiante.getCursos().remove(curso);
	            estudianteService.save(estudiante);
	            response.put("mensaje", "Curso eliminado del estudiante correctamente");
	        } else {
	            response.put("mensaje", "El curso no estaba asignado al estudiante");
	        }

	        response.put("fecha", LocalDateTime.now());
	        response.put("datos", estudiante.getCursos());
	        return new ResponseEntity<>(response, HttpStatus.OK);

	    } catch (Exception e) {
	        response.put("mensaje", "Error al eliminar el curso del estudiante");
	        response.put("fecha", LocalDateTime.now());
	        response.put("error", e.getMessage());
	        return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	}
	
	
	
	@GetMapping("/estudiante/estudiante-{id}/cursos")
	public ResponseEntity<?> listarCursosPorEstudiante(@PathVariable Long id) {
	    Map<String, Object> response = new LinkedHashMap<>();

	    try {
	        Estudiante estudiante = estudianteService.findById(id);

	        if (estudiante == null) {
	            response.put("mensaje", "Estudiante no encontrado con ID: " + id);
	            response.put("fecha", LocalDateTime.now());
	            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
	        }

	        response.put("mensaje", "Cursos del estudiante obtenidos correctamente");
	        response.put("fecha", LocalDateTime.now());
	        response.put("datos", estudiante.getCursos());
	        return new ResponseEntity<>(response, HttpStatus.OK);

	    } catch (Exception e) {
	        response.put("mensaje", "Error al obtener los cursos del estudiante");
	        response.put("fecha", LocalDateTime.now());
	        response.put("error", e.getMessage());
	        return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	}
	
	
}
