package com.cursos.apirest.models.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cursos.apirest.models.entities.Curso;

@Repository
public interface ICursosDAO extends CrudRepository<Curso, Long>{
	List<Curso> findByActivo(Integer activo);
}
