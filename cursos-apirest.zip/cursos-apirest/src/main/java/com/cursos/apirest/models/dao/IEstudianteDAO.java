package com.cursos.apirest.models.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.cursos.apirest.models.entities.Estudiante;

@Repository
public interface IEstudianteDAO extends CrudRepository<Estudiante, Long>{
	List<Estudiante> findByActivo(Integer activo);
}
