package com.cursos.apirest.models.services;
import java.util.List;

import com.cursos.apirest.models.entities.Estudiante;


public interface IEstudianteService {
	List<Estudiante> findAll();
	List<Estudiante> findAllActive();
	Estudiante save(Estudiante u);
	Estudiante findById(Long id);
	void delete(Estudiante u);
	void deleteById(Long id);
}
