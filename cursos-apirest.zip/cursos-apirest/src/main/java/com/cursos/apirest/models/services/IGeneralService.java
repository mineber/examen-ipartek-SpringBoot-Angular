package com.cursos.apirest.models.services;

import java.util.List;

import org.springframework.stereotype.Service;

@Service
public interface IGeneralService<T> {
	
	  List<T> findAll();
	  List<T> findAllActive();
	  T save(T t);
	  T findById(Long id);
	  void deleteById(Long id);
	  
	  
}
