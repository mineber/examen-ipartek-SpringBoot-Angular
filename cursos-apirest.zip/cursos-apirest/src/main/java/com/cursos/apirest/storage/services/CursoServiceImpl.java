package com.cursos.apirest.storage.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cursos.apirest.models.dao.ICursosDAO;
import com.cursos.apirest.models.entities.Curso;
import com.cursos.apirest.models.services.IGeneralService;


@Service
public class CursoServiceImpl implements IGeneralService<Curso>{
	@Autowired
	private ICursosDAO cursosDAO;



	@Override
	public List<Curso> findAll() {
		
		Iterable<Curso> elTipo = cursosDAO.findAll();
		 return (List<Curso>) elTipo;
	
	}

	@Override
	public List<Curso> findAllActive() {
		
		return cursosDAO.findByActivo(1);
	
	}

	@Override
	public Curso save(Curso t) {
		
		return cursosDAO.save(t);
		
	}

	@Override
	public Curso findById(Long id) {
		
		return cursosDAO.findById(id).orElse(null);
		
	}

	@Override
    public void deleteById(Long id) {
		cursosDAO.deleteById(id);
    }

}
