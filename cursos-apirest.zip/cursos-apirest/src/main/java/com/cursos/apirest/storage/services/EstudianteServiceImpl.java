package com.cursos.apirest.storage.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cursos.apirest.models.dao.IEstudianteDAO;
import com.cursos.apirest.models.entities.Estudiante;
import com.cursos.apirest.models.services.IGeneralService;

@Service
public class EstudianteServiceImpl implements IGeneralService<Estudiante>{

	@Autowired
	private IEstudianteDAO estudianteDAO;



	@Override
	public List<Estudiante> findAll() {
		
		Iterable<Estudiante> elTipo = estudianteDAO.findAll();
		 return (List<Estudiante>) elTipo;
	
	}

	@Override
	public List<Estudiante> findAllActive() {
		
		return estudianteDAO.findByActivo(1);
	
	}

	@Override
	public Estudiante save(Estudiante t) {
		
		return estudianteDAO.save(t);
		
	}

	@Override
	public Estudiante findById(Long id) {
		
		return estudianteDAO.findById(id).orElse(null);
		
	}
	
	@Override
    public void deleteById(Long id) {
		estudianteDAO.deleteById(id);
    }
}
