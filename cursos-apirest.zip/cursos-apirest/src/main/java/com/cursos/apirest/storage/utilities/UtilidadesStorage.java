package com.cursos.apirest.storage.utilities;


import java.io.IOException;
import java.util.List;

import org.apache.tika.Tika;
import org.apache.tika.mime.MimeType;
import org.apache.tika.mime.MimeTypeException;
import org.apache.tika.mime.MimeTypes;
import org.springframework.web.multipart.MultipartFile;

public class UtilidadesStorage {
	
	//Este método comprueba si el tipo MIME del archivo MultipartFile recibido como argumento
	//es permitido (concuerda con algún tipo de los pasados en el ArrayList también recibido como argumento
	//En el caso de exsista concordancia  (el tipoo sea permitido) devuelve el tipo REAL ("image/jpeg"...etc.)
	public static String compruebaTipoMIME(MultipartFile file, List<String> tiposPermitidos ) throws IOException{
		
		//Extraemos el nombre del archivo con su extensión, del MultipartFile
		//Esta operación es susceptible de lanzar un NullPointerException
		
		String nombreDelArchivo = file.getOriginalFilename().toLowerCase(); //cocina.jpg, presentacion.pptx
		
		//El método "getInputStream" puede lanzar un IOException
		//tipoDetectado es el tipo REAL "INTERNO" del MultipartFile.Es decir no extraído de la extensión del archivo (que podría ser falsa)
		String tipoDetectado = new Tika().detect(file.getInputStream()); //"image/jpeg","application/pdf"
		
		//Hay diversos tipos que TIKA detecta y que requieren de una normalización
		//poraque no son "interpretables" directamente 
		
		String tipoNormalizado = normalizaMIMEParaTIKA(tipoDetectado, nombreDelArchivo);
		
		if(!tiposPermitidos.contains(tipoNormalizado)) {
			
			throw new RuntimeException("Error al subir al archivo. El archivo que has intentado subir no está permitido");
		}
		
		return tipoNormalizado;
		
		
	}
	
	
	public static String devuelveExtensionDeTipoMIME(String tipoNormalizado) throws MimeTypeException{
		
		//Pasar el tipo MIME ("image/jpeg" o "image/png) a ".jpg" o ".png"
		MimeTypes allMimeTypes =  MimeTypes.getDefaultMimeTypes();
		MimeType  tipoMime =  allMimeTypes.forName(tipoNormalizado);
		return tipoMime.getExtension(); //".jpg" (TIKA devuelve por defecto ".jpg",".pdf",".exe" es decir la extensión REAL 
		
		
	}
	
	
	
	
	public static String normalizaMIMEParaTIKA(String tipoDetectado, String filename) {
		
		
		String tipoNormalizado = tipoDetectado;//Si no entramos en los if (.jpg,.pdf,.png)
		//El método devuelve lo que recibe
		
		//Limpiamos el tipoDetectado de posibles apuntes que haya hecho tika...
		if(tipoDetectado.contains(";")) {
			
			tipoDetectado = tipoDetectado.split(";")[0].trim();
		}
		
	    // Normalizar para docx (word),xlsx(excel),pptx(power point)
	    if (tipoDetectado.equals("application/x-tika-ooxml") && filename.endsWith(".docx")) {
	        tipoNormalizado = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
	    } else if (tipoDetectado.equals("application/x-tika-ooxml") && filename.endsWith(".xlsx")) {
	        tipoNormalizado = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
	    } else if (tipoDetectado.equals("application/x-tika-ooxml") && filename.endsWith(".pptx")) {
	        tipoNormalizado = "application/vnd.openxmlformats-officedocument.presentationml.presentation";
	    } else if( (tipoDetectado.equals("application/x-rar-compressed")||tipoDetectado.equals("application/vnd.rar")||tipoDetectado.equals("application/octet-stream")) && filename.endsWith(".rar")) {
	    	tipoNormalizado = "application/x-rar-compressed";
	    }
	    
	    return tipoNormalizado;
		
		
	}
	

}
