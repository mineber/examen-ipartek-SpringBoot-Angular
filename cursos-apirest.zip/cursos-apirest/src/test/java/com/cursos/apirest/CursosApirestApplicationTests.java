package com.cursos.apirest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CursosApirestApplicationTests {

	@Test
	void contextLoads() {
	}

}
