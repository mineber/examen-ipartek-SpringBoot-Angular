export const URL_BASE:string = "http://localhost:8080/";
export const URL_API:string = URL_BASE + "api/";
export const URL_MEDIA:string = URL_BASE + "media/";
export const URL_MEDIA_IMAGEN:string = URL_MEDIA + "imagen/";