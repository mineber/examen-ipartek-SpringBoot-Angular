export interface Banner{

    titular:string;
    claim:string;
    urlImagen:string;
    link:string;

}