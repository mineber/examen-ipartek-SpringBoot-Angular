import { Component } from '@angular/core';

@Component({
  selector: 'app-social-media-footer',
  imports: [],
  templateUrl: './social-media-footer.html',
  styleUrl: './social-media-footer.css'
})
export class SocialMediaFooter {

}
